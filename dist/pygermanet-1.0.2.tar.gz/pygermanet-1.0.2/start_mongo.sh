#!/bin/bash

mkdir -p ./mongodb
mongod --dbpath ./mongodb
